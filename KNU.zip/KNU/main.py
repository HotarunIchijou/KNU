from system.utils import logtosys, shell

logtosys.logintosys
shell.kosh()
