class absys:
    def about():
        about = "KNU/KolotovkinOS v1.6.1\nПринципиально новая Операционная Система, написанная на Python 💩"
        return about
