class shutdown:
    def off():
        return "Завершение работы системы"
