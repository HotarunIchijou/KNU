class helpinf:
    def helpotpt():
        help = '''Kosh в разработке, поэтому комманд крайне мало. Вот полный список комманд:
            help или помргите -- справка
            poweroff, off или shutdown -- выключение
            whatstime или wtime -- дата и время
            about -- информация о системе
            kolfetch -- вызов утилиты kolfetch, которая показывает информацию о системе
            mkusr -- создать нового пользователя'''
        return help
